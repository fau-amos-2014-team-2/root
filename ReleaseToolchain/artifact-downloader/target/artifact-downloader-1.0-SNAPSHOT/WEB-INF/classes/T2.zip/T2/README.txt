Our "Hello World"-Projects that are to be seen as a result for this week's sprint can be found in the repository.
--> mgwtApp
--> vaadinApp
They couldn't be included in this file, because the size of it was getting too big to push to git.