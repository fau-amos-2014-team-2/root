$wnd.com_fau_amos_team2_WoundManagement_gwt_AppWidgetSet.runAsyncCallback2('YRb(3223,1,Cig);_.hc=function JPe(){CPc((!xPc&&(xPc=new EPc),xPc),this.b.e)};Yjg(Cj)(2);\n//@ sourceURL=2.js\n')
