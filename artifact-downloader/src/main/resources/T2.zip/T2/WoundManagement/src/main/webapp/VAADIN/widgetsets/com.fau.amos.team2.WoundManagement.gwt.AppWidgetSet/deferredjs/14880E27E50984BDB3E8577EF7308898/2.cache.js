$wnd.com_fau_amos_team2_WoundManagement_gwt_AppWidgetSet.runAsyncCallback2('gRb(3185,1,Afg);_.hc=function dMe(){YLc((!TLc&&(TLc=new $Lc),TLc),this.b.e)};Vgg(Bj)(2);\n//@ sourceURL=2.js\n')
