$wnd.com_fau_amos_team2_WoundManagement_gwt_AppWidgetSet.runAsyncCallback2('pRb(3198,1,cgg);_.cc=function YMe(){RMc((!MMc&&(MMc=new TMc),MMc),this.a.d)};zhg(rj)(2);\n//@ sourceURL=2.js\n')
