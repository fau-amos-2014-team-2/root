PhoneGap-Start for Vaadin projects
---

A starting point for PhoneGap apps that wrap Vaadin app.

To get started: fork this repo, modify the config.xml and index.html to match your details, and get building!
